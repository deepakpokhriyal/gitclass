# # import pyodbc as p
# # from datetime import date
# #
# # def connection():
# #     ConnectionString = "DRIVER={MySQL ODBC 8.0 ANSI Driver};SERVER=localhost;DATABASE=amazon;USER=root;PASSWORD=root;OPTION=3;"
# #     cnxn = p.connect(ConnectionString)
# #     cursor = cnxn.cursor()
# #     return cursor,cnxn
# #
# # def check():
# #     c, conn = connection()
# #     query = "SELECT date(exp_date),`user_id`,`use_pass`,`amazon_id` from `general_user` WHERE `user_id`=? AND `use_pass`=?"
# #     a="amit"
# #     p="amit"
# #     c.execute(query,a,p)
# #     data = c.fetchall()
# #     # if data>=date.today():
# #     #     print("hello")
# #     # else:
# #     #     print("hiii")
# #
# #     if data[0][0]>=date.today():
# #         print("hello")
# #     else:
# #         print("hiiii")
# #
# #
# #     # ss=str(data[0][0]).split(" ")
# #     # dd=ss[0].split("-")
# #     # print(dd)
# #     #
# #     #
# #     # today = date.today()
# #     # todayy=str(today).split('-')
# #     # print(todayy)
# #     #
# #     # if dd[0]>=todayy[0] and dd[1]>=todayy[1] and dd[2]>=todayy[2]:
# #     #     print("Expired")
# #     # else:
# #     #     print("Remaining")
# #
# #
# #     conn.close()
# #
# # if __name__ == '__main__':
# #     check()
#
#
# from selenium import webdriver
# import time
#
#
#
#
# driver = webdriver.Firefox()
# driver.maximize_window()
#
# driver.get("http://www.csgnetwork.com/directautoyear.html")
#
# time.sleep(2)
#
# el = driver.find_element_by_xpath('/html/body/font/div/font/table/tbody/tr[2]/td[2]/center/div/form/select')
# for option in el.find_elements_by_tag_name('option'):
#     if option.text == '1934':
#         option.click() # select() in earlier versions of webdriver
#         break
#
# # select = Select(driver.find_element_by_xpath('/html/body/font/div/font/table/tbody/tr[2]/td[2]/center/div/form/select'))
#
# # driver.close()



from selenium import webdriver
import time
from selenium.webdriver.support.ui import WebDriverWait as wait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.action_chains import ActionChains
flag=0
sh=""



def test():

    driver = webdriver.Firefox()
    driver.maximize_window()

    driver.get("https://www.amazon.com/")
    time.sleep(2)

    venue = wait(driver, 5).until(EC.element_to_be_clickable((By.XPATH, '//*[@id="nav-link-accountList"]')))
    venue.click()
    time.sleep(1)

        # email
    driver.find_element_by_xpath('//*[@id="ap_email"]').send_keys('efcesso@mailnesia.com')

    time.sleep(2)
        # password
    driver.find_element_by_xpath('//*[@id="ap_password"]').send_keys('bingo@123tech')

    time.sleep(2)

    venue2 = wait(driver, 5).until(EC.element_to_be_clickable((By.XPATH, '//*[@id="signInSubmit"]')))
    venue2.click()

    time.sleep(5)


    driver.find_element_by_xpath('//*[@id="twotabsearchtextbox"]').send_keys('SMART BAND')
    time.sleep(2)

    search_product = wait(driver, 5).until(
        EC.element_to_be_clickable((By.XPATH, '/html/body/div[1]/header/div/div[1]/div[3]/div/form/div[2]/div/input')))
    search_product.click()
    time.sleep(2)

    ia=input("Enter ASIN NUMBER:: ")

    for d in range(19):
        try:
            for i in range(1,20):
                i=str(i)

                try:
                    v = driver.find_element_by_xpath('/html/body/div[1]/div[1]/div[1]/div[2]/div/span[3]/div[1]/div['+i+']').get_attribute('data-asin')


                except:
                    v = driver.find_element_by_xpath('/html/body/div[1]/div[2]/div[1]/div[2]/div/span[3]/div[1]/div['+i+']').get_attribute('data-asin')
                print(v)
                global sh
                sh='/html/body/div[1]/div[1]/div[1]/div[2]/div/span[3]/div[1]/div['+i+']'


                if v==ia:
                    global flag
                    flag=1
                    print("here we get the product")
                    break
            if flag==1:
                break
            time.sleep(2)

            driver.find_element_by_css_selector('.a-last > a:nth-child(1)').click()
        except:
            driver.refresh()

    if flag==1:
        print(sh)
        driver.find_element_by_xpath(sh).click()
        driver.find_element_by_xpath(sh).find_element_by_xpath('').click()

        # a=driver.find_element_by_xpath('//*[@id="twotabsearchtextbox"]')
        # a.clear()
        # a.send_keys(ia)
        # driver.find_element_by_xpath('/html/body/div[1]/header/div/div[1]/div[3]/div/form/div[2]/div/input').click()
"'''""""
        try:
            driver.find_element_by_xpath('/html/body/div[1]/div[2]/div[1]/div[2]/div/span[3]/div[1]/div/div/div/div/div[2]/div[1]/div/div/span/a/div/img').click()
        except:
            driver.find_element_by_xpath('/html/body/div[1]/div[1]/div[1]/div[2]/div/span[3]/div[1]/div/div/div/div/div[2]/div[1]/div/div/span/a/div/img').click()
        time.sleep(5)

        driver.find_element_by_xpath('//*[@id="add-to-cart-button"]').click()
        time.sleep(5)

        driver.find_element_by_id('hlb-ptc-btn-native').click()
        time.sleep(3)

        driver.find_element_by_xpath('//*[@id="enterAddressAddressLine1"]').send_keys('CANNON BEACH CANNON BEACH')

        time.sleep(2)

        driver.find_element_by_xpath('//*[@id="enterAddressAddressLine2"]').send_keys('156 ROSS LN')

        time.sleep(1)

        driver.find_element_by_xpath('//*[@id="enterAddressCity"]').send_keys('Cannon beach')

        time.sleep(1)

        driver.find_element_by_xpath('//*[@id="enterAddressStateOrRegion"]').send_keys('OR')

        time.sleep(1)

        driver.find_element_by_xpath('//*[@id="enterAddressPostalCode"]').send_keys('97110-3179')
        time.sleep(1)

        driver.find_element_by_xpath('//*[@id="enterAddressPhoneNumber"]').send_keys('910-670-7290')
        time.sleep(3)

        book = wait(driver, 5).until(EC.element_to_be_clickable(
            (By.XPATH, '/html/body/div[5]/div[2]/div[2]/div[1]/div/div[1]/div/form/div[7]/span/span/input')))
        book.click()

        time.sleep(3)

        venue8 = wait(driver, 5).until(EC.element_to_be_clickable(
            (By.XPATH, '//*[@id="shippingOptionFormId"]/div[3]/div/div/span[1]/span/input')))
        venue8.click()

        time.sleep(3)

        driver.find_element_by_xpath('//*[@id="ccName"]').send_keys('SAHIL')

        time.sleep(3)

        driver.find_element_by_xpath('//*[@id="addCreditCardNumber"]').send_keys('5599 1102 5411 5010')
        time.sleep(2)

        try:
            yearclick1 = wait(driver, 5).until(EC.element_to_be_clickable((By.XPATH,'/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button')))
            yearclick1.click()
        except:
            yearclick1 = wait(driver, 5).until(EC.element_to_be_clickable((By.XPATH,'/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button')))
            yearclick1.click()
        time.sleep(2)


        month=input("Enter MONTH ::")
        year=input("Enter YEAR ::")
        #01
        if month=="01" and year=="2019":
            #month_button
            try:
                driver.find_element_by_xpath('/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath('/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()

            time.sleep(2)
            #month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath('/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath('/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()

            time.sleep(2)
            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[1]/a').click()
        #02
        elif month=="01" and year=="2020":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            #year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[2]/a').click()
        # 03
        elif month == "01" and year == "2021":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[3]/a').click()
        # 04
        elif month == "01" and year == "2022":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[4]/a').click()
        # 05
        elif month == "01" and year == "2023":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[5]/a').click()
        # 06
        elif month == "01" and year == "2024":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[6]/a').click()
        # 07
        elif month == "01" and year == "2025":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[7]/a').click()
        # 08
        elif month == "01" and year == "2026":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[8]/a').click()
        # 09
        elif month == "01" and year == "2027":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[9]/a').click()
        # 10
        elif month == "01" and year == "2028":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[10]/a').click()
        # 11
        elif month == "01" and year == "2029":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[11]/a').click()
        # 12
        elif month == "01" and year == "2030":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[12]/a').click()
        # 13
        elif month == "01" and year == "2031":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[13]/a').click()
        # 14
        elif month == "01" and year == "2032":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[14]/a').click()
        # 15
        elif month == "01" and year == "2033":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[15]/a').click()
        # 16
        elif month == "01" and year == "2034":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[16]/a').click()
        # 17
        elif month == "01" and year == "2035":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[17]/a').click()
        # 18
        elif month == "01" and year == "2036":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[18]/a').click()
        # 19
        elif month == "01" and year == "2037":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[19]/a').click()
        # 20
        elif month == "01" and year == "2038":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[20]/a').click()
        # 21
        elif month == "01" and year == "2039":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[21]/a').click()

         #combination of 02 month
        #01
        elif month=="02" and year=="2019":
            #month_button
            try:
                driver.find_element_by_xpath('/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath('/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()

            time.sleep(2)
            #month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath('/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath('/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()

            time.sleep(2)
            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[1]/a').click()

        #02
        elif month=="02" and year=="2020":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[2]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            #year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[2]/a').click()
        # 03
        elif month == "02" and year == "2021":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[2]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[3]/a').click()
        # 04
        elif month == "02" and year == "2022":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[2]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[4]/a').click()
        # 05
        elif month == "02" and year == "2023":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[2]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[5]/a').click()
        # 06
        elif month == "02" and year == "2024":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[2]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[6]/a').click()
        # 07
        elif month == "02" and year == "2025":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[2]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[7]/a').click()
        # 08
        elif month == "02" and year == "2026":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[2]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[8]/a').click()
        # 09
        elif month == "02" and year == "2027":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[2]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[9]/a').click()
        # 10
        elif month == "02" and year == "2028":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[2]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[10]/a').click()
        # 11
        elif month == "02" and year == "2029":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[2]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[11]/a').click()
        # 12
        elif month == "02" and year == "2030":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[2]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[12]/a').click()
        # 13
        elif month == "02" and year == "2031":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[2]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[13]/a').click()
        # 14
        elif month == "02" and year == "2032":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[2]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[14]/a').click()
        # 15
        elif month == "02" and year == "2033":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[2]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[15]/a').click()
        # 16
        elif month == "02" and year == "2034":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[2]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[16]/a').click()
        # 17
        elif month == "02" and year == "2035":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[2]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[17]/a').click()
        # 18
        elif month == "02" and year == "2036":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[2]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[18]/a').click()
        # 19
        elif month == "02" and year == "2037":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[2]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[19]/a').click()
        # 20
        elif month == "02" and year == "2038":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[2]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[20]/a').click()
        # 21
        elif month == "02" and year == "2039":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[2]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[21]/a').click()

        #combination of 03
        # 01
        elif month == "03" and year == "2019":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[1]/a').click()


        #02
        elif month=="03" and year=="2020":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            #year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[2]/a').click()
        # 03
        elif month == "03" and year == "2021":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[3]/a').click()
        # 04
        elif month == "03" and year == "2022":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[4]/a').click()
        # 05
        elif month == "03" and year == "2023":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[5]/a').click()
        # 06
        elif month == "03" and year == "2024":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[6]/a').click()
        # 07
        elif month == "03" and year == "2025":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[7]/a').click()
        # 08
        elif month == "03" and year == "2026":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[8]/a').click()
        # 09
        elif month == "03" and year == "2027":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[9]/a').click()
        # 10
        elif month == "03" and year == "2028":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[10]/a').click()
        # 11
        elif month == "03" and year == "2029":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[11]/a').click()
        # 12
        elif month == "03" and year == "2030":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[12]/a').click()
        # 13
        elif month == "03" and year == "2031":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[13]/a').click()
        # 14
        elif month == "03" and year == "2032":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[14]/a').click()
        # 15
        elif month == "03" and year == "2033":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[15]/a').click()
        # 16
        elif month == "03" and year == "2034":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[16]/a').click()
        # 17
        elif month == "03" and year == "2035":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[17]/a').click()
        # 18
        elif month == "03" and year == "2036":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[18]/a').click()
        # 19
        elif month == "03" and year == "2037":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[19]/a').click()
        # 20
        elif month == "03" and year == "2038":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[20]/a').click()
        # 21
        elif month == "03" and year == "2039":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[21]/a').click()

        # combination of 04
        # 01
        elif month == "04" and year == "2019":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[4]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[1]/a').click()


        # 02
        elif month == "04" and year == "2020":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[4]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[2]/a').click()
        # 03
        elif month == "04" and year == "2021":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[4]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[3]/a').click()
        # 04
        elif month == "04" and year == "2022":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[4]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[4]/a').click()
        # 05
        elif month == "04" and year == "2023":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[4]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[5]/a').click()
        # 06
        elif month == "04" and year == "2024":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[4]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[6]/a').click()
        # 07
        elif month == "04" and year == "2025":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[4]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[7]/a').click()
        # 08
        elif month == "04" and year == "2026":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[4]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[8]/a').click()
        # 09
        elif month == "04" and year == "2027":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[4]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[9]/a').click()
        # 10
        elif month == "04" and year == "2028":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[4]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[10]/a').click()
        # 11
        elif month == "04" and year == "2029":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[4]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[11]/a').click()
        # 12
        elif month == "04" and year == "2030":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[4]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[12]/a').click()
        # 13
        elif month == "04" and year == "2031":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[4]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[13]/a').click()
        # 14
        elif month == "04" and year == "2032":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[4]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[14]/a').click()
        # 15
        elif month == "03" and year == "2033":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[15]/a').click()
        # 16
        elif month == "04" and year == "2034":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[4]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[16]/a').click()
        # 17
        elif month == "04" and year == "2035":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[4]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[17]/a').click()
        # 18
        elif month == "04" and year == "2036":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[4]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[18]/a').click()
        # 19
        elif month == "04" and year == "2037":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[4]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[19]/a').click()
        # 20
        elif month == "04" and year == "2038":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[4]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[20]/a').click()
        # 21
        elif month == "04" and year == "2039":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[4]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[21]/a').click()

        # combination of 05
        # 01
        elif month == "05" and year == "2019":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[1]/a').click()


        # 02
        elif month == "05" and year == "2020":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[2]/a').click()
        # 03
        elif month == "05" and year == "2021":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[3]/a').click()
        # 04
        elif month == "05" and year == "2022":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[4]/a').click()
        # 05
        elif month == "05" and year == "2023":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[5]/a').click()
        # 06
        elif month == "05" and year == "2024":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[6]/a').click()
        # 07
        elif month == "05" and year == "2025":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[7]/a').click()
        # 08
        elif month == "05" and year == "2026":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[8]/a').click()
        # 09
        elif month == "05" and year == "2027":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/htm`l/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[9]/a').click()
        # 10
        elif month == "05" and year == "2028":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[10]/a').click()
        # 11
        elif month == "05" and year == "2029":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[11]/a').click()
        # 12
        elif month == "05" and year == "2030":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[12]/a').click()
        # 13
        elif month == "05" and year == "2031":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[13]/a').click()
        # 14
        elif month == "05" and year == "2032":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[14]/a').click()
        # 15
        elif month == "05" and year == "2033":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[15]/a').click()
        # 16
        elif month == "05" and year == "2034":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[16]/a').click()
        # 17
        elif month == "05" and year == "2035":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[17]/a').click()
        # 18
        elif month == "05" and year == "2036":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[18]/a').click()
        # 19
        elif month == "05" and year == "2037":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[19]/a').click()
        # 20
        elif month == "05" and year == "2038":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[20]/a').click()
        # 21
        elif month == "05" and year == "2039":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[21]/a').click()

        # combination of 06
        # 01
        elif month == "06" and year == "2019":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[1]/a').click()


        # 02
        elif month == "06" and year == "2020":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[2]/a').click()
        # 03
        elif month == "06" and year == "2021":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[3]/a').click()
        # 04
        elif month == "06" and year == "2022":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[4]/a').click()
        # 05
        elif month == "06" and year == "2023":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[5]/a').click()
        # 06
        elif month == "06" and year == "2024":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[6]/a').click()
        # 07
        elif month == "06" and year == "2025":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[7]/a').click()
        # 08
        elif month == "06" and year == "2026":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[8]/a').click()
        # 09
        elif month == "06" and year == "2027":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[9]/a').click()
        # 10
        elif month == "06" and year == "2028":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[10]/a').click()
        # 11
        elif month == "06" and year == "2029":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[11]/a').click()
        # 12
        elif month == "06" and year == "2030":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[12]/a').click()
        # 13
        elif month == "06" and year == "2031":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[13]/a').click()
        # 14
        elif month == "06" and year == "2032":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[14]/a').click()
        # 15
        elif month == "06" and year == "2033":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[15]/a').click()
        # 16
        elif month == "06" and year == "2034":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[16]/a').click()
        # 17
        elif month == "06" and year == "2035":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[17]/a').click()
        # 18
        elif month == "06" and year == "2036":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[18]/a').click()
        # 19
        elif month == "06" and year == "2037":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[19]/a').click()
        # 20
        elif month == "06" and year == "2038":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[20]/a').click()
        # 21
        elif month == "06" and year == "2039":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[21]/a').click()

        # combination of 07
        # 01
        elif month == "07" and year == "2019":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[1]/a').click()


        # 02
        elif month == "03" and year == "2020":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[2]/a').click()
        # 03
        elif month == "07" and year == "2021":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[7]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[3]/a').click()
        # 04
        elif month == "07" and year == "2022":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[7]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[4]/a').click()
        # 05
        elif month == "07" and year == "2023":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[7]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[5]/a').click()
        # 06
        elif month == "07" and year == "2024":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[7]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[6]/a').click()
        # 07
        elif month == "07" and year == "2025":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[7]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[7]/a').click()
        # 08
        elif month == "07" and year == "2026":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[7]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[8]/a').click()
        # 09
        elif month == "07" and year == "2027":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[7]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[9]/a').click()
        # 10
        elif month == "07" and year == "2028":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[7]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[10]/a').click()
        # 11
        elif month == "07" and year == "2029":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[7]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[11]/a').click()
        # 12
        elif month == "07" and year == "2030":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[7]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[12]/a').click()
        # 13
        elif month == "07" and year == "2031":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[7]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[13]/a').click()
        # 14
        elif month == "07" and year == "2032":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[7]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[14]/a').click()
        # 15
        elif month == "07" and year == "2033":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[7]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[15]/a').click()
        # 16
        elif month == "07" and year == "2034":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[7]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[16]/a').click()
        # 17
        elif month == "07" and year == "2035":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[7]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[17]/a').click()
        # 18
        elif month == "07" and year == "2036":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[7]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[18]/a').click()
        # 19
        elif month == "07" and year == "2037":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[7]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[19]/a').click()
        # 20
        elif month == "07" and year == "2038":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[7]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[20]/a').click()
        # 21
        elif month == "07" and year == "2039":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[7]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[21]/a').click()

        # combination of 03
        # 01
        elif month == "08" and year == "2020":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[1]/a').click()


        # 02
        elif month =="08" and year == "2020":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[2]/a').click()
        # 03
        elif month == "08" and year == "2021":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[3]/a').click()
        # 04
        elif month == "08" and year == "2022":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[4]/a').click()
        # 05
        elif month == "08" and year == "2023":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[5]/a').click()
        # 06
        elif month == "08" and year == "2024":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[6]/a').click()
        # 07
        elif month =="08"and year == "2025":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[7]/a').click()
        # 08
        elif month == "08"and year == "2026":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[8]/a').click()
        # 09
        elif month == "08"and year == "2027":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[9]/a').click()
        # 10
        elif month == "08" and year == "2028":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[10]/a').click()
        # 11
        elif month == "08" and year == "2029":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[11]/a').click()
        # 12
        elif month =="08" and year == "2030":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[12]/a').click()
        # 13
        elif month == "08" and year == "2031":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[13]/a').click()
        # 14
        elif month == "08" and year == "2032":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[14]/a').click()
        # 15
        elif month == "08" and year == "2033":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[15]/a').click()
        # 16
        elif month == "08" and year == "2034":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[16]/a').click()
        # 17
        elif month == "08" and year == "2035":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[17]/a').click()
        # 18
        elif month == "08" and year == "2036":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[18]/a').click()
        # 19
        elif month == "08" and year == "2037":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[19]/a').click()
        # 20
        elif month == "08" and year == "2038":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[20]/a').click()
        # 21
        elif month == "08" and year == "2039":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[21]/a').click()

        # combination of 03
        # 01
        elif month == "09" and year == "2020":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[1]/a').click()

        # 02
        elif month =="09" and year == "2020":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[2]/a').click()
        # 03
        elif month == "09" and year == "2021":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[3]/a').click()
        # 04
        elif month == "09" and year == "2022":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[4]/a').click()
        # 05
        elif month == "09" and year == "2023":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[5]/a').click()
        # 06
        elif month == "09" and year == "2024":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[6]/a').click()
        # 07
        elif month == "09" and year == "2025":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[7]/a').click()
        # 08
        elif month == "09" and year == "2026":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[8]/a').click()
        # 09
        elif month == "09" and year == "2027":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[9]/a').click()
        # 10
        elif month == "09"and year == "2028":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[10]/a').click()
        # 11
        elif month == "09" and year == "2029":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[11]/a').click()
        # 12
        elif month == "09" and year == "2030":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[12]/a').click()
        # 13
        elif month == "09" and year == "2031":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[13]/a').click()
        # 14
        elif month == "09" and year == "2032":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[14]/a').click()
        # 15
        elif month =="09" and year == "2033":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[15]/a').click()
        # 16
        elif month == "09" and year == "2034":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[16]/a').click()
        # 17
        elif month == "09" and year == "2035":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[17]/a').click()
        # 18
        elif month == "09" and year == "2036":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[18]/a').click()
        # 19
        elif month == "09" and year == "2037":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[19]/a').click()
        # 20
        elif month == "09" and year == "2038":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[20]/a').click()
        # 21
        elif month == "09" and year == "2039":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[21]/a').click()

        # combination of 03
        # 01
        elif month == "10" and year == "2020":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[1]/a').click()


        # 02
        elif month =="10"and year == "2020":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[2]/a').click()
        # 03
        elif month == "10" and year == "2021":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[3]/a').click()
        # 04
        elif month == "10" and year == "2022":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[4]/a').click()
        # 05
        elif month == "10" and year == "2023":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[5]/a').click()
        # 06
        elif month == "10" and year == "2024":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[6]/a').click()
        # 07
        elif month == "10" and year == "2025":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[7]/a').click()
        # 08
        elif month == "10" and year == "2026":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[8]/a').click()
        # 09
        elif month == "10" and year == "2027":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[9]/a').click()
        # 10
        elif month == "10" and year == "2028":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[10]/a').click()
        # 11
        elif month == "10" and year == "2029":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[11]/a').click()
        # 12
        elif month == "10" and year == "2030":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[12]/a').click()
        # 13
        elif month == "10" and year == "2031":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[13]/a').click()
        # 14
        elif month == "10" and year == "2032":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[14]/a').click()
        # 15
        elif month == "10" and year == "2033":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[15]/a').click()
        # 16
        elif month == "10" and year == "2034":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[16]/a').click()
        # 17
        elif month == "10" and year == "2035":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[17]/a').click()
        # 18
        elif month == "10" and year == "2036":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[18]/a').click()
        # 19
        elif month == "10" and year == "2037":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[19]/a').click()
        # 20
        elif month == "10" and year == "2038":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[20]/a').click()
        # 21
        elif month == "10" and year == "2039":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[21]/a').click()

        # combination of 11
        # 01
        elif month == "11" and year == "2020":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[1]/a').click()


        # 02
        elif month =="11"and year == "2020":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[2]/a').click()
        # 03
        elif month == "11" and year == "2021":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[3]/a').click()
        # 04
        elif month == "11" and year == "2022":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[4]/a').click()
        # 05
        elif month == "11" and year == "2023":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[5]/a').click()
        # 06
        elif month =="11" and year == "2024":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[6]/a').click()
        # 07
        elif month == "11" and year == "2025":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[7]/a').click()
        # 08
        elif month =="11" and year == "2026":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[8]/a').click()
        # 09
        elif month == "11" and year == "2027":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[9]/a').click()
        # 10
        elif month == "11" and year == "2028":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[10]/a').click()
        # 11
        elif month =="11" and year == "2029":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[11]/a').click()
        # 12
        elif month == "11" and year == "2030":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[12]/a').click()
        # 13
        elif month == "11" and year == "2031":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[13]/a').click()
        # 14
        elif month == "11" and year == "2032":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[14]/a').click()
        # 15
        elif month == "11" and year == "2033":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[15]/a').click()
        # 16
        elif month == "11" and year == "2034":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[16]/a').click()
        # 17
        elif month == "11"and year == "2035":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[17]/a').click()
        # 18
        elif month == "11" and year == "2036":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[18]/a').click()
        # 19
        elif month == "11" and year == "2037":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[19]/a').click()
        # 20
        elif month == "11" and year == "2038":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[20]/a').click()
        # 21
        elif month == "11" and year == "2039":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[21]/a').click()

        # combination of 12
        # 01
        elif month == "12" and year == "2020":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[1]/a').click()


        # 02
        elif month == "12" and year == "2020":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[2]/a').click()
        # 03
        elif month == "12" and year == "2021":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[3]/a').click()
        # 04
        elif month == "12" and year == "2022":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[4]/a').click()
        # 05
        elif month == "12" and year == "2023":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[5]/a').click()
        # 06
        elif month == "12" and year == "2024":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[6]/a').click()
        # 07
        elif month == "12" and year == "2025":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[7]/a').click()
        # 08
        elif month == "12" and year == "2026":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[8]/a').click()
        # 09
        elif month == "12" and year == "2027":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[9]/a').click()
        # 10
        elif month == "12"and year == "2028":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[10]/a').click()
        # 11
        elif month =="12" and year == "2029":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[11]/a').click()
        # 12
        elif month == "12" and year == "2030":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[12]/a').click()
        # 13
        elif month == "12" and year == "2031":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[13]/a').click()
        # 14
        elif month == "12" and year == "2032":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[14]/a').click()
        # 15
        elif month == "12" and year == "2033":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[15]/a').click()
        # 16
        elif month == "12" and year == "2034":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[16]/a').click()
        # 17
        elif month == "12" and year == "2035":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[17]/a').click()
        # 18
        elif month == "12" and year == "2036":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[18]/a').click()
        # 19
        elif month == "12" and year == "2037":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[19]/a').click()
        # 20
        elif month == "12" and year == "2038":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[20]/a').click()
        # 21
        elif month == "12" and year == "2039":
            # month_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
                time.sleep(2)
            # month_01
            driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

            time.sleep(2)

            # year_button
            try:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            except:
                driver.find_element_by_xpath(
                    '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
                time.sleep(2)

            # year_2020
            driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[21]/a').click()



        time.sleep(2)

        venue9 = wait(driver, 5).until(EC.element_to_be_clickable(
            (By.XPATH, '//*[@id="ccAddCard"]')))
        venue9.click()

        time.sleep(2)

        driver.find_element_by_xpath('/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/form/div[2]/div/div/div[1]/div[3]/div[2]/div[1]/div[1]/div[2]/div[2]/div[1]/span/span/span/button').click()
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()



        time.sleep(2)

        driver.refresh()

        time.sleep(5)


        venue10 = wait(driver, 5).until(EC.element_to_be_clickable((By.XPATH, '//*[@id="continue-top"]')))
        venue10.click()

        time.sleep(2)

        driver.find_element_by_xpath('/html/body/div[5]/div[1]/div[2]/form/div/div/div/div[2]/div/div[1]/div/div[1]/div/span/span/input').click()
        time.sleep(2)



        time.sleep(10)

        # signout code

        ele = driver.find_element_by_xpath('//*[@id="nav-link-accountList"]')
        hover = ActionChains(driver).move_to_element(ele)
        hover.perform()

        time.sleep(2)
        driver.find_element_by_css_selector('#nav-item-signout > span:nth-child(1)').click()

        time.sleep(10)

        driver.close()



    else:
        print("No Product")
"'''"""""
if __name__ == '__main__':
    test()