from selenium import webdriver
import time

def expdate():

    month = input("Enter MONTH ::")
    year = input("Enter YEAR ::")
    # 01
    if month == "01" and year == "2019":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()

        time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()

        time.sleep(2)
        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[1]/a').click()
    # 02
    elif month == "01" and year == "2020":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[2]/a').click()
    # 03
    elif month == "01" and year == "2021":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[3]/a').click()
    # 04
    elif month == "01" and year == "2022":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[4]/a').click()
    # 05
    elif month == "01" and year == "2023":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[5]/a').click()
    # 06
    elif month == "01" and year == "2024":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[6]/a').click()
    # 07
    elif month == "01" and year == "2025":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[7]/a').click()
    # 08
    elif month == "01" and year == "2026":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[8]/a').click()
    # 09
    elif month == "01" and year == "2027":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[9]/a').click()
    # 10
    elif month == "01" and year == "2028":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[10]/a').click()
    # 11
    elif month == "01" and year == "2029":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[11]/a').click()
    # 12
    elif month == "01" and year == "2030":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[12]/a').click()
    # 13
    elif month == "01" and year == "2031":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[13]/a').click()
    # 14
    elif month == "01" and year == "2032":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[14]/a').click()
    # 15
    elif month == "01" and year == "2033":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[15]/a').click()
    # 16
    elif month == "01" and year == "2034":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[16]/a').click()
    # 17
    elif month == "01" and year == "2035":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[17]/a').click()
    # 18
    elif month == "01" and year == "2036":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[18]/a').click()
    # 19
    elif month == "01" and year == "2037":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[19]/a').click()
    # 20
    elif month == "01" and year == "2038":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[20]/a').click()
    # 21
    elif month == "01" and year == "2039":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[21]/a').click()

    # combination of 02 month
    # 01
    elif month == "02" and year == "2019":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()

        time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[1]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()

        time.sleep(2)
        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[1]/a').click()

    # 02
    elif month == "02" and year == "2020":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[2]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[2]/a').click()
    # 03
    elif month == "02" and year == "2021":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[2]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[3]/a').click()
    # 04
    elif month == "02" and year == "2022":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[2]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[4]/a').click()
    # 05
    elif month == "02" and year == "2023":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[2]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[5]/a').click()
    # 06
    elif month == "02" and year == "2024":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[2]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[6]/a').click()
    # 07
    elif month == "02" and year == "2025":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[2]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[7]/a').click()
    # 08
    elif month == "02" and year == "2026":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[2]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[8]/a').click()
    # 09
    elif month == "02" and year == "2027":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[2]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[9]/a').click()
    # 10
    elif month == "02" and year == "2028":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[2]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[10]/a').click()
    # 11
    elif month == "02" and year == "2029":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[2]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[11]/a').click()
    # 12
    elif month == "02" and year == "2030":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[2]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[12]/a').click()
    # 13
    elif month == "02" and year == "2031":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[2]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[13]/a').click()
    # 14
    elif month == "02" and year == "2032":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[2]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[14]/a').click()
    # 15
    elif month == "02" and year == "2033":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[2]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[15]/a').click()
    # 16
    elif month == "02" and year == "2034":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[2]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[16]/a').click()
    # 17
    elif month == "02" and year == "2035":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[2]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[17]/a').click()
    # 18
    elif month == "02" and year == "2036":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[2]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[18]/a').click()
    # 19
    elif month == "02" and year == "2037":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[2]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[19]/a').click()
    # 20
    elif month == "02" and year == "2038":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[2]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[20]/a').click()
    # 21
    elif month == "02" and year == "2039":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[2]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[21]/a').click()

    # combination of 03
    # 01
    elif month == "03" and year == "2019":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[1]/a').click()


    # 02
    elif month == "03" and year == "2020":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[2]/a').click()
    # 03
    elif month == "03" and year == "2021":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[3]/a').click()
    # 04
    elif month == "03" and year == "2022":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[4]/a').click()
    # 05
    elif month == "03" and year == "2023":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[5]/a').click()
    # 06
    elif month == "03" and year == "2024":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[6]/a').click()
    # 07
    elif month == "03" and year == "2025":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[7]/a').click()
    # 08
    elif month == "03" and year == "2026":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[8]/a').click()
    # 09
    elif month == "03" and year == "2027":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[9]/a').click()
    # 10
    elif month == "03" and year == "2028":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[10]/a').click()
    # 11
    elif month == "03" and year == "2029":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[11]/a').click()
    # 12
    elif month == "03" and year == "2030":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[12]/a').click()
    # 13
    elif month == "03" and year == "2031":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[13]/a').click()
    # 14
    elif month == "03" and year == "2032":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[14]/a').click()
    # 15
    elif month == "03" and year == "2033":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[15]/a').click()
    # 16
    elif month == "03" and year == "2034":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[16]/a').click()
    # 17
    elif month == "03" and year == "2035":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[17]/a').click()
    # 18
    elif month == "03" and year == "2036":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[18]/a').click()
    # 19
    elif month == "03" and year == "2037":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[19]/a').click()
    # 20
    elif month == "03" and year == "2038":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[20]/a').click()
    # 21
    elif month == "03" and year == "2039":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[21]/a').click()

    # combination of 04
    # 01
    elif month == "04" and year == "2019":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[4]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[1]/a').click()


    # 02
    elif month == "04" and year == "2020":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[4]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[2]/a').click()
    # 03
    elif month == "04" and year == "2021":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[4]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[3]/a').click()
    # 04
    elif month == "04" and year == "2022":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[4]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[4]/a').click()
    # 05
    elif month == "04" and year == "2023":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[4]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[5]/a').click()
    # 06
    elif month == "04" and year == "2024":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[4]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[6]/a').click()
    # 07
    elif month == "04" and year == "2025":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[4]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[7]/a').click()
    # 08
    elif month == "04" and year == "2026":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[4]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[8]/a').click()
    # 09
    elif month == "04" and year == "2027":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[4]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[9]/a').click()
    # 10
    elif month == "04" and year == "2028":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[4]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[10]/a').click()
    # 11
    elif month == "04" and year == "2029":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[4]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[11]/a').click()
    # 12
    elif month == "04" and year == "2030":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[4]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[12]/a').click()
    # 13
    elif month == "04" and year == "2031":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[4]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[13]/a').click()
    # 14
    elif month == "04" and year == "2032":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[4]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[14]/a').click()
    # 15
    elif month == "03" and year == "2033":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[15]/a').click()
    # 16
    elif month == "04" and year == "2034":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[4]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[16]/a').click()
    # 17
    elif month == "04" and year == "2035":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[4]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[17]/a').click()
    # 18
    elif month == "04" and year == "2036":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[4]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[18]/a').click()
    # 19
    elif month == "04" and year == "2037":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[4]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[19]/a').click()
    # 20
    elif month == "04" and year == "2038":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[4]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[20]/a').click()
    # 21
    elif month == "04" and year == "2039":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[4]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[21]/a').click()

    # combination of 05
    # 01
    elif month == "05" and year == "2019":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[1]/a').click()


    # 02
    elif month == "05" and year == "2020":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[2]/a').click()
    # 03
    elif month == "05" and year == "2021":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[3]/a').click()
    # 04
    elif month == "05" and year == "2022":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[4]/a').click()
    # 05
    elif month == "05" and year == "2023":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[5]/a').click()
    # 06
    elif month == "05" and year == "2024":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[6]/a').click()
    # 07
    elif month == "05" and year == "2025":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[7]/a').click()
    # 08
    elif month == "05" and year == "2026":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[8]/a').click()
    # 09
    elif month == "05" and year == "2027":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/htm`l/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[9]/a').click()
    # 10
    elif month == "05" and year == "2028":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[10]/a').click()
    # 11
    elif month == "05" and year == "2029":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[11]/a').click()
    # 12
    elif month == "05" and year == "2030":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[12]/a').click()
    # 13
    elif month == "05" and year == "2031":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[13]/a').click()
    # 14
    elif month == "05" and year == "2032":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[14]/a').click()
    # 15
    elif month == "05" and year == "2033":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[15]/a').click()
    # 16
    elif month == "05" and year == "2034":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[16]/a').click()
    # 17
    elif month == "05" and year == "2035":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[17]/a').click()
    # 18
    elif month == "05" and year == "2036":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[18]/a').click()
    # 19
    elif month == "05" and year == "2037":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[19]/a').click()
    # 20
    elif month == "05" and year == "2038":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[20]/a').click()
    # 21
    elif month == "05" and year == "2039":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[21]/a').click()

    # combination of 06
    # 01
    elif month == "06" and year == "2019":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[1]/a').click()


    # 02
    elif month == "06" and year == "2020":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[2]/a').click()
    # 03
    elif month == "06" and year == "2021":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[3]/a').click()
    # 04
    elif month == "06" and year == "2022":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[4]/a').click()
    # 05
    elif month == "06" and year == "2023":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[5]/a').click()
    # 06
    elif month == "06" and year == "2024":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[6]/a').click()
    # 07
    elif month == "06" and year == "2025":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[7]/a').click()
    # 08
    elif month == "06" and year == "2026":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[8]/a').click()
    # 09
    elif month == "06" and year == "2027":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[9]/a').click()
    # 10
    elif month == "06" and year == "2028":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[10]/a').click()
    # 11
    elif month == "06" and year == "2029":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[11]/a').click()
    # 12
    elif month == "06" and year == "2030":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[12]/a').click()
    # 13
    elif month == "06" and year == "2031":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[13]/a').click()
    # 14
    elif month == "06" and year == "2032":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[14]/a').click()
    # 15
    elif month == "06" and year == "2033":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[15]/a').click()
    # 16
    elif month == "06" and year == "2034":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[16]/a').click()
    # 17
    elif month == "06" and year == "2035":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[17]/a').click()
    # 18
    elif month == "06" and year == "2036":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[18]/a').click()
    # 19
    elif month == "06" and year == "2037":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[19]/a').click()
    # 20
    elif month == "06" and year == "2038":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[20]/a').click()
    # 21
    elif month == "06" and year == "2039":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[6]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[21]/a').click()

    # combination of 07
    # 01
    elif month == "07" and year == "2019":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[1]/a').click()


    # 02
    elif month == "03" and year == "2020":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[3]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[2]/a').click()
    # 03
    elif month == "07" and year == "2021":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[7]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[3]/a').click()
    # 04
    elif month == "07" and year == "2022":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[7]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[4]/a').click()
    # 05
    elif month == "07" and year == "2023":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[7]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[5]/a').click()
    # 06
    elif month == "07" and year == "2024":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[7]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[6]/a').click()
    # 07
    elif month == "07" and year == "2025":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[7]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[7]/a').click()
    # 08
    elif month == "07" and year == "2026":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[7]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[8]/a').click()
    # 09
    elif month == "07" and year == "2027":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[7]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[9]/a').click()
    # 10
    elif month == "07" and year == "2028":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[7]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[10]/a').click()
    # 11
    elif month == "07" and year == "2029":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[7]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[11]/a').click()
    # 12
    elif month == "07" and year == "2030":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[7]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[12]/a').click()
    # 13
    elif month == "07" and year == "2031":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[7]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[13]/a').click()
    # 14
    elif month == "07" and year == "2032":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[7]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[14]/a').click()
    # 15
    elif month == "07" and year == "2033":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[7]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[15]/a').click()
    # 16
    elif month == "07" and year == "2034":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[7]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[16]/a').click()
    # 17
    elif month == "07" and year == "2035":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[7]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[17]/a').click()
    # 18
    elif month == "07" and year == "2036":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[7]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[18]/a').click()
    # 19
    elif month == "07" and year == "2037":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[7]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[19]/a').click()
    # 20
    elif month == "07" and year == "2038":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[7]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[20]/a').click()
    # 21
    elif month == "07" and year == "2039":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[7]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[21]/a').click()

    # combination of 03
    # 01
    elif month == "08" and year == "2020":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[1]/a').click()


    # 02
    elif month == "08" and year == "2020":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[2]/a').click()
    # 03
    elif month == "08" and year == "2021":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[3]/a').click()
    # 04
    elif month == "08" and year == "2022":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[4]/a').click()
    # 05
    elif month == "08" and year == "2023":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[5]/a').click()
    # 06
    elif month == "08" and year == "2024":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[6]/a').click()
    # 07
    elif month == "08" and year == "2025":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[7]/a').click()
    # 08
    elif month == "08" and year == "2026":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[8]/a').click()
    # 09
    elif month == "08" and year == "2027":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[9]/a').click()
    # 10
    elif month == "08" and year == "2028":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[10]/a').click()
    # 11
    elif month == "08" and year == "2029":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[11]/a').click()
    # 12
    elif month == "08" and year == "2030":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[12]/a').click()
    # 13
    elif month == "08" and year == "2031":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[13]/a').click()
    # 14
    elif month == "08" and year == "2032":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[14]/a').click()
    # 15
    elif month == "08" and year == "2033":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[15]/a').click()
    # 16
    elif month == "08" and year == "2034":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[16]/a').click()
    # 17
    elif month == "08" and year == "2035":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[17]/a').click()
    # 18
    elif month == "08" and year == "2036":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[18]/a').click()
    # 19
    elif month == "08" and year == "2037":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[19]/a').click()
    # 20
    elif month == "08" and year == "2038":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[20]/a').click()
    # 21
    elif month == "08" and year == "2039":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[8]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[21]/a').click()

    # combination of 03
    # 01
    elif month == "09" and year == "2020":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[1]/a').click()

    # 02
    elif month == "09" and year == "2020":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[2]/a').click()
    # 03
    elif month == "09" and year == "2021":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[3]/a').click()
    # 04
    elif month == "09" and year == "2022":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[4]/a').click()
    # 05
    elif month == "09" and year == "2023":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[5]/a').click()
    # 06
    elif month == "09" and year == "2024":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[6]/a').click()
    # 07
    elif month == "09" and year == "2025":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[7]/a').click()
    # 08
    elif month == "09" and year == "2026":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[8]/a').click()
    # 09
    elif month == "09" and year == "2027":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[9]/a').click()
    # 10
    elif month == "09" and year == "2028":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[10]/a').click()
    # 11
    elif month == "09" and year == "2029":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[11]/a').click()
    # 12
    elif month == "09" and year == "2030":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[12]/a').click()
    # 13
    elif month == "09" and year == "2031":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[13]/a').click()
    # 14
    elif month == "09" and year == "2032":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[14]/a').click()
    # 15
    elif month == "09" and year == "2033":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[15]/a').click()
    # 16
    elif month == "09" and year == "2034":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[16]/a').click()
    # 17
    elif month == "09" and year == "2035":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[17]/a').click()
    # 18
    elif month == "09" and year == "2036":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[18]/a').click()
    # 19
    elif month == "09" and year == "2037":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[19]/a').click()
    # 20
    elif month == "09" and year == "2038":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[20]/a').click()
    # 21
    elif month == "09" and year == "2039":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[9]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[21]/a').click()

    # combination of 03
    # 01
    elif month == "10" and year == "2020":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[1]/a').click()


    # 02
    elif month == "10" and year == "2020":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[2]/a').click()
    # 03
    elif month == "10" and year == "2021":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[3]/a').click()
    # 04
    elif month == "10" and year == "2022":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[4]/a').click()
    # 05
    elif month == "10" and year == "2023":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[5]/a').click()
    # 06
    elif month == "10" and year == "2024":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[6]/a').click()
    # 07
    elif month == "10" and year == "2025":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[7]/a').click()
    # 08
    elif month == "10" and year == "2026":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[8]/a').click()
    # 09
    elif month == "10" and year == "2027":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[9]/a').click()
    # 10
    elif month == "10" and year == "2028":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[10]/a').click()
    # 11
    elif month == "10" and year == "2029":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[11]/a').click()
    # 12
    elif month == "10" and year == "2030":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[12]/a').click()
    # 13
    elif month == "10" and year == "2031":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[13]/a').click()
    # 14
    elif month == "10" and year == "2032":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[14]/a').click()
    # 15
    elif month == "10" and year == "2033":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[15]/a').click()
    # 16
    elif month == "10" and year == "2034":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[16]/a').click()
    # 17
    elif month == "10" and year == "2035":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[17]/a').click()
    # 18
    elif month == "10" and year == "2036":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[18]/a').click()
    # 19
    elif month == "10" and year == "2037":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[19]/a').click()
    # 20
    elif month == "10" and year == "2038":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[20]/a').click()
    # 21
    elif month == "10" and year == "2039":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[10]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[21]/a').click()

    # combination of 11
    # 01
    elif month == "11" and year == "2020":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[1]/a').click()


    # 02
    elif month == "11" and year == "2020":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[2]/a').click()
    # 03
    elif month == "11" and year == "2021":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[3]/a').click()
    # 04
    elif month == "11" and year == "2022":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[4]/a').click()
    # 05
    elif month == "11" and year == "2023":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[5]/a').click()
    # 06
    elif month == "11" and year == "2024":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[6]/a').click()
    # 07
    elif month == "11" and year == "2025":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[7]/a').click()
    # 08
    elif month == "11" and year == "2026":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[8]/a').click()
    # 09
    elif month == "11" and year == "2027":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[9]/a').click()
    # 10
    elif month == "11" and year == "2028":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[10]/a').click()
    # 11
    elif month == "11" and year == "2029":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[11]/a').click()
    # 12
    elif month == "11" and year == "2030":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[12]/a').click()
    # 13
    elif month == "11" and year == "2031":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[13]/a').click()
    # 14
    elif month == "11" and year == "2032":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[14]/a').click()
    # 15
    elif month == "11" and year == "2033":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[15]/a').click()
    # 16
    elif month == "11" and year == "2034":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[16]/a').click()
    # 17
    elif month == "11" and year == "2035":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[17]/a').click()
    # 18
    elif month == "11" and year == "2036":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[18]/a').click()
    # 19
    elif month == "11" and year == "2037":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[19]/a').click()
    # 20
    elif month == "11" and year == "2038":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[20]/a').click()
    # 21
    elif month == "11" and year == "2039":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[11]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[21]/a').click()

    # combination of 12
    # 01
    elif month == "12" and year == "2020":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[1]/a').click()


    # 02
    elif month == "12" and year == "2020":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[2]/a').click()
    # 03
    elif month == "12" and year == "2021":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[3]/a').click()
    # 04
    elif month == "12" and year == "2022":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[4]/a').click()
    # 05
    elif month == "12" and year == "2023":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[5]/a').click()
    # 06
    elif month == "12" and year == "2024":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[6]/a').click()
    # 07
    elif month == "12" and year == "2025":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[7]/a').click()
    # 08
    elif month == "12" and year == "2026":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[8]/a').click()
    # 09
    elif month == "12" and year == "2027":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[9]/a').click()
    # 10
    elif month == "12" and year == "2028":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[10]/a').click()
    # 11
    elif month == "12" and year == "2029":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[11]/a').click()
    # 12
    elif month == "12" and year == "2030":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[12]/a').click()
    # 13
    elif month == "12" and year == "2031":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[13]/a').click()
    # 14
    elif month == "12" and year == "2032":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[14]/a').click()
    # 15
    elif month == "12" and year == "2033":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[15]/a').click()
    # 16
    elif month == "12" and year == "2034":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[16]/a').click()
    # 17
    elif month == "12" and year == "2035":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[17]/a').click()
    # 18
    elif month == "12" and year == "2036":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[18]/a').click()
    # 19
    elif month == "12" and year == "2037":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[19]/a').click()
    # 20
    elif month == "12" and year == "2038":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[20]/a').click()
    # 21
    elif month == "12" and year == "2039":
        # month_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[1]/span/span/button').click()
            time.sleep(2)
        # month_01
        driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[12]/a').click()

        time.sleep(2)

        # year_button
        try:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
        except:
            driver.find_element_by_xpath(
                '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button  ').click()
            time.sleep(2)

        # year_2020
        driver.find_element_by_xpath('/html/body/div[9]/div/div/ul/li[21]/a').click()

    time.sleep(2)