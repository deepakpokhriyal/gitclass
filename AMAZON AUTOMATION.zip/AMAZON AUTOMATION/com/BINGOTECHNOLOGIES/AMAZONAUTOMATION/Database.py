import pyodbc as p



ConnectionString = "DRIVER={MySQL ODBC 8.0 ANSI Driver};SERVER=localhost;DATABASE=amazon;USER=root;PASSWORD=root;OPTION=3;"
cnxn=p.connect(ConnectionString)
cursor=cnxn.cursor()


class Data:

    def Datarecord(a,b,c,d):
        cursor.execute("INSERT INTO `amazon_data` (`email_id`, `Name`, `Password`,`flag`,`amazon_id`) VALUES ('{}','{}','{}','{}','{}');".format(a,b,c,'new',d))
        cnxn.commit()
