from com.BINGOTECHNOLOGIES.AMAZONAUTOMATION.EMAILSIGNUP_OTP.emailsignup import *
from com.BINGOTECHNOLOGIES.AMAZONAUTOMATION import Database
from com.BINGOTECHNOLOGIES.AMAZONAUTOMATION.AMAZON_SIGNUP import random_name
from selenium.webdriver.common.action_chains import ActionChains

def automate(su):
    ab=su
    driver = webdriver.Firefox()
    driver.maximize_window()

    driver.get("https://www.amazon.com/")

    time.sleep(2)
    venue = wait(driver, 5).until(EC.element_to_be_clickable((By.XPATH, '//*[@id="nav-link-accountList"]')))
    venue.click()

    time.sleep(1)


    driver.find_element_by_id("createAccountSubmit").click()
    rm=mail.random_mail(1)
    time.sleep(1)
    rmm=rm+"@mailnesia.com"
    nm=random_name.r_name()
    ps="bingo@123tech"
    driver.find_element_by_xpath('//*[@id="ap_customer_name"]').send_keys(nm)
    driver.find_element_by_xpath('//*[@id="ap_email"]').send_keys(rmm)
    driver.find_element_by_xpath('//*[@id="ap_password"]').send_keys(ps)
    driver.find_element_by_xpath('//*[@id="ap_password_check"]').send_keys(ps)

    time.sleep(5)

    driver.find_element_by_id("continue").click()
    time.sleep(5)

    rm1 = mail.getotp(1)

    driver.find_element_by_xpath('//*[@id="cvf-page-content"]/div/div/div[1]/form/div[2]/input').send_keys(rm1)
    time.sleep(2)

    driver.find_element_by_class_name("a-button-input").click()

    time.sleep(2)

    ele = driver.find_element_by_xpath('//*[@id="nav-link-accountList"]')
    hover = ActionChains(driver).move_to_element(ele)
    hover.perform()

    time.sleep(2)
    driver.find_element_by_css_selector('#nav-item-signout > span:nth-child(1)').click()

    time.sleep(5)

    Database.Data.Datarecord(rmm,nm,ps,ab)


    driver.close()


# if __name__ == '__main__':
#     automate()