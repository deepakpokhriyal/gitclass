import random

def r_name():
    names=["Aadi singh","Aarav kumar","Aarnav kaushik","Aarush kumar","Aayush arora","Abdul khan","Abeer khan","Abhimanyu kumar","Abhiramnew das","Aditya kumar",
           "Advaith kartik","Advay dhingra","Advik sharma","Agastya verma ","Akshay tiwari","Amol joshi","Anay jain","Anirudhnew khureshi","Anmol nagpal ",
           "Ansh choudary","Arin yadav","Arjun baisla","Arnav gujjar","Aryan basioya","Atharv kumar","Avi kumari","Ayaan singh","Ayush saxena","Ayushman khurana",
           "Azaan singh","Azad khan","Daksh chopra","Darsh kashyap","Dev das","Devansh singh","Dhruv singhal","Farhan khan","Gautam gupta","Harsh kasuhik",
           "Harshil tomar","Hredhaan khaan","Isaac jain","Ishaan khan","Jainew ","Jason mathew","Kabir khan","Kalpit kumar","Karan singh","Kiaan kumaari",
           "Krish saxena","Krishna singh","Laksh gupta","Lakshay kumar","Manannew","Mohammed aamir","Nachiket ","Naksh das","Nakul yadav","Neel raj","Om tiwari",
           "Parth singh","Pranav singh","Praneel kumar","Pranit chopra","Pratyush singh","Rachit das","Raghav kumar","Ranbir singh","Ranveer gupta","ayaan khan",
           "Rehaannew","Reyansh singh","Rishi jain","Rohan khasyap","Ronith singh","Rudranew chopra","Rushil singh","Ryan chopra","Sai ram","Saksham singh",
           "Samaksh gupta","Samar khan","Samarth singhania","Samesh singh","Sarthak chopra","Sathviknew kashyap","Shaurya singh","Shivansh singh",
           "Siddharth singhania","Tejas mathur","Vedant singh","Veer khan","Viaannew jain","Vihaan singh","Viraj chopra","Vivaan kunar","Yash gupta","Yug singh",
           "Zayan khan"]

    rand_name=names[random.randrange(len(names))]

    return rand_name