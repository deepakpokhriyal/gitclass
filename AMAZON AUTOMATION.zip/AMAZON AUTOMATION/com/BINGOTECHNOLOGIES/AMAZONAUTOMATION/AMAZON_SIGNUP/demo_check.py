import pyodbc as p
from datetime import date

def connection():
    ConnectionString = "DRIVER={MySQL ODBC 8.0 ANSI Driver};SERVER=localhost;DATABASE=amazon;USER=root;PASSWORD=root;OPTION=3;"
    cnxn = p.connect(ConnectionString)
    cursor = cnxn.cursor()
    return cursor,cnxn

def check():
    c, conn = connection()
    query = "SELECT date(exp_date),`user_id`,`use_pass`,`amazon_id` from `general_user` WHERE `user_id`=? AND `use_pass`=?"
    a="amit"
    p="amit"
    c.execute(query,a,p)
    data = c.fetchall()
    # if data>=date.today():
    #     print("hello")
    # else:
    #     print("hiii")

    if data[0][0]>=date.today():
        print("hello")
    else:
        print("hiiii")


    # ss=str(data[0][0]).split(" ")
    # dd=ss[0].split("-")
    # print(dd)
    #
    #
    # today = date.today()
    # todayy=str(today).split('-')
    # print(todayy)
    #
    # if dd[0]>=todayy[0] and dd[1]>=todayy[1] and dd[2]>=todayy[2]:
    #     print("Expired")
    # else:
    #     print("Remaining")


    conn.close()

if __name__ == '__main__':
    check()