from flask import Flask,render_template,request,session,abort,flash,redirect,url_for
import os
from com.BINGOTECHNOLOGIES.AMAZONAUTOMATION.AMAZON_SIGNUP.signup import automate
from com.BINGOTECHNOLOGIES.AMAZONAUTOMATION.Amazon_Purchase.amazon_pur import purchaseprod
import pyodbc as p
import MySQLdb
from datetime import date


su=0
le=[]
user_id=""

def connection():
    ConnectionString = "DRIVER={MySQL ODBC 8.0 ANSI Driver};SERVER=localhost;DATABASE=amazon;USER=root;PASSWORD=root;OPTION=3;"
    cnxn = p.connect(ConnectionString)
    cursor = cnxn.cursor()
    return cursor,cnxn

def shutdown_server():
    func = request.environ.get('werkzeug.server.shutdown')
    if func is None:
        raise RuntimeError('Not running with the Werkzeug Server')
    func()

app = Flask(__name__)


db = MySQLdb.connect(host="localhost", user="root", passwd="root", db="amazon")
cur = db.cursor()

@app.route('/')
def hello_world():
    return render_template('index.html')

@app.route('/start',methods=['POST'])
def start_service():
    n=int(request.form['no_acc'])
    for i in range(n):
        automate(su)
    return render_template('normal_login.html')

@app.route('/normal_login')
def normal_login():
    return render_template("normal_login.html")


@app.route('/stop')
def stop_service():
    shutdown_server()
    return render_template('normal_login.html')


@app.route('/', methods=['POST'])
def do_normal_login():
    c, conn = connection()
    query = "SELECT `user_id`,`use_pass`,`amazon_id`,date(exp_date) from `general_user`"
    c.execute(query)
    data = c.fetchall()

    query = "SELECT `s_user-id`,`s_user_pass` from `s_user`"
    c.execute(query)
    data2 = c.fetchall()
    conn.close()
    for i in data:
        if request.form['password'] == str(i[1]) and request.form['username'] == str(i[0]):
            if i[3] >= date.today():
                global su
                su= str(i[2])
                global user_id
                user_id=str(i[0])
                session['logged_in'] = True
                return redirect('/normal_login')
                break
            else:
                flash('Account Expired.')
                return redirect('/')
        elif request.form['password'] == data2[0][1] and request.form['username'] == data2[0][0]:
            session['logged_in'] = True
            return redirect('/s_user')
            break
    else:
        return hello_world()

# @app.route('/logout',methods=['GET''POST'])
# def logout():
#     if request.method =='POST':
#         session.pop('username', None)
#     return redirect(url_for('index'))
# app.secret_key = 'A0Zr98j/3yX R~XHH!jmN]LWX/,?RT'


@app.route('/s_user_pass', methods=['POST'])
def chg_pass():
    if str(request.form['new_pass']) == str(request.form['con_pass']):
        s=str(request.form['new_pass'])
        try:
            c, conn = connection()
            query = "UPDATE `amazon`.`s_user` SET `s_user_pass` = ? WHERE `p_id` = 1001;"
            val = s
            c.execute(query,val)
            conn.commit()
            conn.close()
            session['logged_in'] = False
            return redirect('/')
        except Exception as e:
            return (str(e))
    else:
        flash('password not matched!')
        return render_template('s_user_pass.html')



@app.route('/n_user_pass', methods=['POST'])
def nchg_pass():
    if str(request.form['new_pass']) == str(request.form['con_pass']):
        s=str(request.form['new_pass'])
        try:
            c, conn = connection()
            query = "UPDATE `amazon`.`general_user` SET `use_pass` = ? WHERE `user_id` = ?;"
            val = s
            c.execute(query,val,user_id)
            conn.commit()
            conn.close()
            session['logged_in'] = False
            return redirect('/')
        except Exception as e:
            return (str(e))
    else:
        flash('password not matched!')
        return render_template('n_pass.html')





@app.route('/s_user/')
def display_deals():
    try:
        c, conn = connection()
        query = "SELECT * from `amazon_data`"
        c.execute(query)
        data = c.fetchall()
        conn.close()
        # return data
        return render_template("s_user.html", data=data)
    except Exception as e:
        return (str(e))

@app.route('/delete_user')
def fetch_user():
    try:
        c, conn = connection()
        query = "SELECT `user_id` from `general_user`"
        c.execute(query)
        user_l = c.fetchall()
        conn.close()
        # return data
        return render_template('delete_user.html', fu=user_l)
    except Exception as e:
        print(e)

@app.route('/d_user', methods=['POST'])
def dele_user():
    del_users=request.form['fetch_all']
    c, conn = connection()
    query = "DELETE FROM `amazon`.`general_user` WHERE `user_id`=?;"
    c.execute(query,del_users)
    conn.commit()
    conn.close()
    return render_template('delete_user.html')


@app.route('/user_status')
def user_stat():
    try:
        c, conn = connection()
        query = "SELECT * from `general_user`"
        c.execute(query)
        user_ll = c.fetchall()
        conn.close()
        # return data
        return render_template('user_status.html', fuu=user_ll)
    except Exception as e:
        print(e)

@app.route('/s_user_pass')
def s_user_pass():
    return render_template('s_user_pass.html')


@app.route('/create_user')
def create_user():
    return render_template('create_user.html')


@app.route('/delete_user')
def delete_user():
    return render_template('delete_user.html')

@app.route('/logout')
def logout():
    session['logged_in'] = False
    return render_template('index.html')

@app.route('/logoutn')
def logoutn():
    session['logged_in'] = False
    return render_template('index.html')

@app.route('/purchase')
def purchase():
    try:
        c, conn = connection()
        fl="new"
        query = "SELECT `email_id` from `amazon_data` WHERE `amazon_id`=? AND `flag`=?"
        val=su
        c.execute(query,val,fl)
        am_all = c.fetchall()
        global le
        le=am_all
        conn.close()
        return render_template('purchase_product.html', am=am_all)
    except Exception as e:
        print(e)


@app.route('/purchase_prod', methods=['POST'])
def purchase_prod():
    purchaseprod(le)
    return render_template('purchase_product.html')


@app.route('/back_n_pass')
def back_n_pass():
    return render_template('normal_login.html')

@app.route('/backnr_user')
def backnr_user():
    return render_template('normal_login.html')

@app.route('/user_status')
def user_status():
    return render_template('user_status.html')

@app.route('/back_cr')
def back_cr():
    return redirect('/s_user')

@app.route('/back_dl')
def back_dl():
    return redirect('/s_user')

@app.route('/back_st')
def back_st():
    return redirect('/s_user')

@app.route('/n_pass',methods=['GET','POST'])
def n_pass():
    if request.method=='POST':
        return redirect(url_for('n_pass'))
    return render_template('n_pass.html')



@app.route('/c_user', methods=['POST'])
def add_user():
    try:
        u_id=request.form['user_id']
        u_pass=request.form['user_pass']
        s_date = request.form['sub_date']
        e_date = request.form['exp_date']
        c, conn = connection()
        query = "INSERT INTO `amazon`.`general_user` (`p_id`, `user_id`, `use_pass`, `subs_date`, `exp_date`) VALUES ('1001', ?, ?, ?, ?);"
        c.execute(query,u_id,u_pass,s_date,e_date)
        conn.commit()
        conn.close()
        return redirect(url_for('create_user'))
    except Exception as e:
        return (str(e))





if __name__ == '__main__':

    app.secret_key = os.urandom(12)
    app.run(debug="True")


