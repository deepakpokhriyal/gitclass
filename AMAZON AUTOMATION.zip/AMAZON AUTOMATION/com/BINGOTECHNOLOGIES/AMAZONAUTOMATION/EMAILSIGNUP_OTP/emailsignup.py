from selenium import webdriver
import time
from selenium.webdriver.support.ui import WebDriverWait as wait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By


class mail:
    g=""
    def random_mail(self):
        driver = webdriver.Firefox()
        driver.maximize_window()

        driver.get("http://mailnesia.com/")

        time.sleep(2)

        venue1 = wait(driver, 5).until(EC.element_to_be_clickable((By.XPATH, '//*[@id="header"]/div[2]/a')))
        venue1.click()

        txt1 = driver.find_element_by_xpath('//*[@id="mailbox"]').get_attribute("value")
        mail.g=txt1

        driver.close()

        return txt1



    def getotp(self):
        driver = webdriver.Firefox()
        driver.maximize_window()

        driver.get("http://mailnesia.com/")

        time.sleep(2)

        driver.find_element_by_xpath('//*[@id="mailbox"]').send_keys(mail.g)

        driver.find_element_by_id("sm").click()

        venue2 = wait(driver, 5).until(EC.element_to_be_clickable((By.XPATH, '/html/body/table/tbody/tr/td[2]/a')))
        venue2.click()

        time.sleep(10)
        txt2=driver.find_element_by_css_selector(".otp").text
        driver.close()
        return txt2

