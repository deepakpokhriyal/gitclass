import xlrd
from flask import flash
from selenium import webdriver
import time
from selenium.webdriver.support.ui import WebDriverWait as wait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
flag=0
import pyodbc as p


def getotp(j):
    driver = webdriver.Firefox()
    driver.maximize_window()

    driver.get("http://mailnesia.com/")

    time.sleep(2)

    driver.find_element_by_xpath('//*[@id="mailbox"]').send_keys(j)

    driver.find_element_by_id("sm").click()

    venue2 = wait(driver, 5).until(EC.element_to_be_clickable((By.XPATH, '/html/body/table/tbody/tr/td[2]/a')))
    venue2.click()

    time.sleep(10)
    txt2 = driver.find_element_by_css_selector(".otp").text
    driver.close()
    return txt2


def connection():
    ConnectionString = "DRIVER={MySQL ODBC 8.0 ANSI Driver};SERVER=localhost;DATABASE=amazon;USER=root;PASSWORD=root;OPTION=3;"
    cnxn = p.connect(ConnectionString)
    cursor = cnxn.cursor()
    return cursor,cnxn


def purchaseprod(s):
    if s:
        for i in s:
            for j in i:
                # print(j)
                # To open Workbook
                wb = xlrd.open_workbook('f:/product.xlsx')
                sheet = wb.sheet_by_index(0)
                # For row 0 and column 0
                pk=sheet.cell_value(1, 0)                       #Product Key
                an=sheet.cell_value(1, 1)                       #Product ASIN NO.

                sheet = wb.sheet_by_index(1)
                # For row 0 and column 0
                ad1=sheet.cell_value(1, 0)                      #Address1
                ad2=sheet.cell_value(1, 1)                      #Address2
                ct=sheet.cell_value(1, 2)                       #City
                st=sheet.cell_value(1, 3)                       #State
                pc=str(sheet.cell_value(1,4))                        #Postal Code
                ph=str(int(sheet.cell_value(1, 5)))                  #Phone No.



                ###########################purchase code###################################

                driver = webdriver.Firefox()
                driver.maximize_window()

                driver.get("https://www.amazon.com/")
                time.sleep(2)

                venue = wait(driver, 5).until(EC.element_to_be_clickable((By.XPATH, '//*[@id="nav-link-accountList"]')))
                venue.click()
                time.sleep(1)



                # email
                driver.find_element_by_xpath('//*[@id="ap_email"]').send_keys(j)

                time.sleep(2)
                # password
                driver.find_element_by_xpath('//*[@id="ap_password"]').send_keys('bingo@123tech')

                time.sleep(2)

                venue2 = wait(driver, 5).until(EC.element_to_be_clickable((By.XPATH, '//*[@id="signInSubmit"]')))
                venue2.click()

                time.sleep(5)


                try:
                    driver.find_element_by_xpath('//*[@id="twotabsearchtextbox"]').send_keys(pk)
                    time.sleep(2)


                except:

                    driver.find_element_by_id('continue').click()

                    otp=getotp(j)

                    driver.find_element_by_xpath('/html/body/div[1]/div[2]/div/div/div/div/div/div[1]/form/div[2]/input').send_keys(otp)
                    driver.find_element_by_xpath('/html/body/div[1]/div[2]/div/div/div/div/div/div[1]/form/div[4]/span/span/input').click()

                    driver.find_element_by_xpath('//*[@id="twotabsearchtextbox"]').send_keys(pk)
                    time.sleep(2)

                    #######################################################





                search_product = wait(driver, 5).until(
                    EC.element_to_be_clickable(
                        (By.XPATH, '/html/body/div[1]/header/div/div[1]/div[3]/div/form/div[2]/div/input')))
                search_product.click()
                time.sleep(2)


                for d in range(19):
                    try:
                        for i in range(1, 20):
                            i = str(i)
                            try:
                                v = driver.find_element_by_xpath(
                                    '/html/body/div[1]/div[1]/div[1]/div[2]/div/span[3]/div[1]/div[' + i + ']').get_attribute(
                                    'data-asin')
                            except:
                                v = driver.find_element_by_xpath(
                                    '/html/body/div[1]/div[2]/div[1]/div[2]/div/span[3]/div[1]/div[' + i + ']').get_attribute(
                                    'data-asin')
                            # print(v)
                            if v == an:
                                global flag
                                flag = 1
                                # print("here we get the product")
                                break
                        if flag == 1:
                            break
                        time.sleep(2)
                        driver.find_element_by_css_selector('.a-last > a:nth-child(1)').click()
                    except:
                        driver.refresh()

                if flag == 1:
                    a = driver.find_element_by_xpath('//*[@id="twotabsearchtextbox"]')
                    a.clear()
                    a.send_keys(an)
                    driver.find_element_by_xpath(
                        '/html/body/div[1]/header/div/div[1]/div[3]/div/form/div[2]/div/input').click()
                    try:
                        driver.find_element_by_xpath(
                            '/html/body/div[1]/div[2]/div[1]/div[2]/div/span[3]/div[1]/div/div/div/div/div[2]/div[1]/div/div/span/a/div/img').click()
                    except:
                        driver.find_element_by_xpath(
                            '/html/body/div[1]/div[1]/div[1]/div[2]/div/span[3]/div[1]/div/div/div/div/div[2]/div[1]/div/div/span/a/div/img').click()
                    time.sleep(5)

                    driver.find_element_by_xpath('//*[@id="add-to-cart-button"]').click()
                    time.sleep(5)
                    try:
                        driver.find_element_by_id('hlb-ptc-btn-native').click()
                    except:
                        try:
                            driver.find_element_by_xpath('/html/body/div[2]/div[1]/div[9]/div[5]/div[1]/div/div/div/div/div[1]/div[3]/div[1]/div[2]/div[3]/span/span/input').click()
                        except:
                            driver.find_element_by_xpath('/html/body/div[2]/div[2]/div[10]/div[5]/div[1]/div/div/div/div/div[1]/div[3]/div[1]/div[2]/div[3]/span/span/input').click()
                    time.sleep(3)

                    driver.find_element_by_xpath('//*[@id="enterAddressAddressLine1"]').send_keys(ad1)

                    time.sleep(2)

                    driver.find_element_by_xpath('//*[@id="enterAddressAddressLine2"]').send_keys(ad2)

                    time.sleep(1)

                    driver.find_element_by_xpath('//*[@id="enterAddressCity"]').send_keys(ct)

                    time.sleep(1)

                    driver.find_element_by_xpath('//*[@id="enterAddressStateOrRegion"]').send_keys(st)

                    time.sleep(1)

                    driver.find_element_by_xpath('//*[@id="enterAddressPostalCode"]').send_keys(pc)
                    time.sleep(1)

                    driver.find_element_by_xpath('//*[@id="enterAddressPhoneNumber"]').send_keys(ph)
                    time.sleep(3)

                    book = wait(driver, 5).until(EC.element_to_be_clickable(
                        (
                        By.XPATH, '/html/body/div[5]/div[2]/div[2]/div[1]/div/div[1]/div/form/div[7]/span/span/input')))
                    book.click()

                    time.sleep(3)

                    venue8 = wait(driver, 5).until(EC.element_to_be_clickable(
                        (By.XPATH, '//*[@id="shippingOptionFormId"]/div[3]/div/div/span[1]/span/input')))
                    venue8.click()

                    time.sleep(3)

                    driver.find_element_by_xpath('//*[@id="ccName"]').send_keys('SAHIL')

                    time.sleep(3)

                    driver.find_element_by_xpath('//*[@id="addCreditCardNumber"]').send_keys('5599 1102 5411 5010')
                    time.sleep(2)

                    try:
                        yearclick1 = wait(driver, 5).until(EC.element_to_be_clickable((By.XPATH,
                                                                                       '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button')))
                        yearclick1.click()
                    except:
                        yearclick1 = wait(driver, 5).until(EC.element_to_be_clickable((By.XPATH,
                                                                                       '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button')))
                        yearclick1.click()
                    time.sleep(2)

                    try:
                        yearclick1 = wait(driver, 5).until(EC.element_to_be_clickable((By.XPATH,
                                                                                       '/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button')))
                        yearclick1.click()
                    except:
                        yearclick1 = wait(driver, 5).until(EC.element_to_be_clickable((By.XPATH,
                                                                                       '/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/div[1]/div/div/div[1]/div[2]/div/form/div[3]/div[4]/span[2]/span/span/button')))
                        yearclick1.click()

                    time.sleep(5)

                    yearclick2 = wait(driver, 5).until(EC.element_to_be_clickable((By.XPATH, '/html/body/div[8]/div/div/ul/li[6]/a')))
                    yearclick2.click()

                    time.sleep(2)

                    venue9 = wait(driver, 5).until(EC.element_to_be_clickable(
                        (By.XPATH, '//*[@id="ccAddCard"]')))
                    venue9.click()

                    time.sleep(2)

                    try:
                        driver.find_element_by_xpath('/html/body/div[5]/div[1]/div[2]/div[2]/div[4]/div/form/div[2]/div/div/div[1]/div[3]/div[2]/div[1]/div[1]/div[2]/div[2]/div[1]/span/span/span/button').click()
                    except:
                        driver.find_element_by_xpath('/html/body/div[5]/div[1]/div[2]/div[2]/div[3]/div/form/div[2]/div/div/div[1]/div[3]/div[2]/div[1]/div[1]/div[2]/div[2]/div[1]/span/span/span/button').click()
                    driver.find_element_by_xpath('/html/body/div[8]/div/div/ul/li[5]/a').click()

                    time.sleep(2)

                    driver.refresh()

                    time.sleep(5)

                    venue10 = wait(driver, 5).until(EC.element_to_be_clickable((By.XPATH, '//*[@id="continue-top"]')))
                    venue10.click()

                    time.sleep(2)
                    try:
                        driver.find_element_by_xpath('/html/body/div[5]/div[1]/div/div[2]/div[1]/form/div[4]/div/div/div[1]/a').click()
                        driver.find_element_by_xpath('/html/body/div[5]/div[1]/div[2]/form/div/div/div/div[2]/div/div[1]/div/div[1]/div/span/span/input').click()
                    except:
                        driver.find_element_by_xpath('/html/body/div[5]/div[1]/div[2]/form/div/div/div/div[2]/div/div[1]/div/div[1]/div/span/span/input').click()
                    time.sleep(2)

                    time.sleep(10)

                    # signout code

                    ele = driver.find_element_by_xpath('//*[@id="nav-link-accountList"]')
                    hover = ActionChains(driver).move_to_element(ele)
                    hover.perform()

                    time.sleep(2)
                    driver.find_element_by_css_selector('#nav-item-signout > span:nth-child(1)').click()

                    time.sleep(10)


                    ##################Data Base Updating From new user to Purchased##########################

                    c, conn = connection()
                    query = "UPDATE `amazon`.`amazon_data` SET `flag` = ? WHERE `email_id` = ?;"
                    val = "purchased"
                    c.execute(query, val,j)
                    conn.commit()
                    conn.close()

                    #########################################################################################


                    driver.close()



                else:
                    print("No Product")


                # ##########################################################################

    else:
        flash('You dont have enough account to purchase!')



